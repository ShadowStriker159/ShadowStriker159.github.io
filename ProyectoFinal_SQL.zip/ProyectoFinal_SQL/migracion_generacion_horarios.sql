DROP DATABASE IF EXISTS sistema_horarios;
CREATE DATABASE sistema_horarios CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sistema_horarios;

CREATE TABLE persona (
    id VARCHAR(20) NOT NULL PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    password VARCHAR(255) NOT NULL,
    correo VARCHAR(255) NOT NULL UNIQUE
);

CREATE TABLE administrador (
    id VARCHAR(20) NOT NULL PRIMARY KEY,
    tipo_administrador VARCHAR(20),
    FOREIGN KEY (id) REFERENCES persona(id)
);

CREATE TABLE docente (
    id VARCHAR(20) NOT NULL PRIMARY KEY,
    escalafon VARCHAR(30),
    estado_docente VARCHAR(20),
    tipo_vinculacion VARCHAR(10),
    FOREIGN KEY (id) REFERENCES persona(id)
);

CREATE TABLE franja_horaria (
    id_franja INT AUTO_INCREMENT PRIMARY KEY,
    dia_semana VARCHAR(20) NOT NULL,
    hora_inicio TIME NOT NULL,
    hora_fin TIME NOT NULL,
    estado_franja VARCHAR(20) NOT NULL DEFAULT 'DISPONIBLE',
    categoria VARCHAR(20) NOT NULL,
    UNIQUE KEY uq_franja (dia_semana, hora_inicio, hora_fin)
);

CREATE TABLE docente_franja (
    id_docente VARCHAR(20) NOT NULL,
    id_franja INT NOT NULL,
    PRIMARY KEY (id_docente, id_franja),
    FOREIGN KEY (id_docente) REFERENCES docente(id),
    FOREIGN KEY (id_franja) REFERENCES franja_horaria(id_franja)
);

CREATE TABLE facultad (
    id_facultad INT AUTO_INCREMENT PRIMARY KEY,
    nombre_facultad VARCHAR(150) NOT NULL UNIQUE
);

CREATE TABLE area (
    id_area INT AUTO_INCREMENT PRIMARY KEY,
    id_facultad INT NOT NULL,
    nombre_area VARCHAR(150) NOT NULL,
    descripcion TEXT,
    FOREIGN KEY (id_facultad) REFERENCES facultad(id_facultad)
);

CREATE TABLE carrera (
    id_carrera INT AUTO_INCREMENT PRIMARY KEY,
    id_facultad INT NOT NULL,
    nombre_carrera VARCHAR(150) NOT NULL,
    FOREIGN KEY (id_facultad) REFERENCES facultad(id_facultad)
);

CREATE TABLE plan_estudios (
    id_plan INT AUTO_INCREMENT PRIMARY KEY,
    id_carrera INT NOT NULL,
    nombre_plan VARCHAR(150) NOT NULL,
    FOREIGN KEY (id_carrera) REFERENCES carrera(id_carrera)
);

CREATE TABLE estudiante (
    id VARCHAR(20) NOT NULL PRIMARY KEY,
    id_plan INT NULL,
    estado_estudiante VARCHAR(30),
    semestre_cursa INT NOT NULL DEFAULT 1,
    creditos_aprobados INT NOT NULL DEFAULT 0,
    FOREIGN KEY (id) REFERENCES persona(id),
    FOREIGN KEY (id_plan) REFERENCES plan_estudios(id_plan)
);

CREATE TABLE curso (
    id_curso INT AUTO_INCREMENT PRIMARY KEY,
    nombre_curso VARCHAR(200) NOT NULL,
    intensidad_horaria INT NOT NULL,
    semestre INT NOT NULL,
    creditos INT NOT NULL,
    aula_requerida VARCHAR(20) NOT NULL
);

CREATE TABLE plan_estudios_curso (
    id_plan INT NOT NULL,
    id_curso INT NOT NULL,
    PRIMARY KEY (id_plan, id_curso),
    FOREIGN KEY (id_plan) REFERENCES plan_estudios(id_plan),
    FOREIGN KEY (id_curso) REFERENCES curso(id_curso)
);

CREATE TABLE curso_prerrequisito (
    id_curso INT NOT NULL,
    id_prerrequisito INT NOT NULL,
    PRIMARY KEY (id_curso, id_prerrequisito),
    FOREIGN KEY (id_curso) REFERENCES curso(id_curso),
    FOREIGN KEY (id_prerrequisito) REFERENCES curso(id_curso)
);

CREATE TABLE bloque (
    id_bloque INT AUTO_INCREMENT PRIMARY KEY,
    nombre_bloque VARCHAR(100) NOT NULL,
    etiqueta_bloque VARCHAR(20) NOT NULL,
    ubicacion VARCHAR(200) NOT NULL
);

CREATE TABLE aula (
    id_bloque INT NOT NULL,
    numero_aula VARCHAR(10) NOT NULL,
    capacidad INT NOT NULL,
    tipo_aula VARCHAR(20) NOT NULL,
    estado_aula VARCHAR(20) NOT NULL,
    PRIMARY KEY (id_bloque, numero_aula),
    FOREIGN KEY (id_bloque) REFERENCES bloque(id_bloque)
);

CREATE TABLE grupo (
    id_grupo INT AUTO_INCREMENT PRIMARY KEY,
    id_curso INT NOT NULL,
    id_docente VARCHAR(20) NOT NULL,
    estado_grupo VARCHAR(20) NOT NULL,
    cupo_maximo INT NOT NULL,
    cupo_minimo INT NOT NULL,
    FOREIGN KEY (id_curso) REFERENCES curso(id_curso),
    FOREIGN KEY (id_docente) REFERENCES docente(id)
);

CREATE TABLE grupo_estudiante (
    id_grupo INT NOT NULL,
    id_estudiante VARCHAR(20) NOT NULL,
    PRIMARY KEY (id_grupo, id_estudiante),
    FOREIGN KEY (id_grupo) REFERENCES grupo(id_grupo),
    FOREIGN KEY (id_estudiante) REFERENCES estudiante(id)
);

CREATE TABLE seccion (
    id_seccion INT AUTO_INCREMENT PRIMARY KEY,
    estado_seccion VARCHAR(20) NOT NULL,
    id_grupo INT NOT NULL,
    id_bloque INT NOT NULL,
    numero_aula VARCHAR(10) NOT NULL,
    id_franja INT NOT NULL,
    FOREIGN KEY (id_grupo) REFERENCES grupo(id_grupo),
    FOREIGN KEY (id_bloque, numero_aula) REFERENCES aula(id_bloque, numero_aula),
    FOREIGN KEY (id_franja) REFERENCES franja_horaria(id_franja)
);
