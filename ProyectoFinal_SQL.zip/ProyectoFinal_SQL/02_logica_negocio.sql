-- =====================================================================
-- 02_logica_negocio.sql  (lógica de negocio mínima en la base de datos)
-- Ejecutar DESPUÉS de migracion_generacion_horarios.sql (el esquema).
-- Se ejecuta con el cliente mysql o MySQL Workbench (usa DELIMITER).
--
-- Errores propios (SQLSTATE '45000', MYSQL_ERRNO):
--   30001 grupo no existe | 30002 estudiante no existe | 30003 ya inscrito
--   30004 regla de negocio | 30005 estudiante no inscrito en el grupo
-- =====================================================================
SET NAMES utf8mb4;
USE sistema_horarios;

-- Auditoría de inscripciones (la escriben los triggers)
DROP TABLE IF EXISTS auditoria;
CREATE TABLE auditoria (
    id_auditoria BIGINT AUTO_INCREMENT PRIMARY KEY,
    operacion    VARCHAR(10)  NOT NULL,
    id_grupo     INT          NOT NULL,
    id_estudiante VARCHAR(20) NOT NULL,
    usuario_bd   VARCHAR(100) NOT NULL,
    fecha        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Integridad declarativa (CHECK)
ALTER TABLE grupo
    ADD CONSTRAINT chk_grupo_cupos  CHECK (cupo_minimo > 0 AND cupo_maximo >= cupo_minimo),
    ADD CONSTRAINT chk_grupo_estado CHECK (estado_grupo IN ('ABIERTO', 'CERRADO'));
ALTER TABLE aula
    ADD CONSTRAINT chk_aula_capacidad CHECK (capacidad > 0);

DELIMITER $$

-- ---------------------------------------------------------------------
-- FUNCIONES
-- ---------------------------------------------------------------------
DROP FUNCTION IF EXISTS fn_cupos_disponibles$$
CREATE FUNCTION fn_cupos_disponibles(p_id_grupo INT) RETURNS INT
    READS SQL DATA
BEGIN
    DECLARE v_max INT;
    DECLARE v_inscritos INT;
    SELECT cupo_maximo INTO v_max FROM grupo WHERE id_grupo = p_id_grupo;
    IF v_max IS NULL THEN
        RETURN NULL;                       -- el grupo no existe
    END IF;
    SELECT COUNT(*) INTO v_inscritos FROM grupo_estudiante WHERE id_grupo = p_id_grupo;
    RETURN v_max - v_inscritos;
END$$

DROP FUNCTION IF EXISTS fn_creditos_inscritos$$
CREATE FUNCTION fn_creditos_inscritos(p_id_estudiante VARCHAR(20)) RETURNS INT
    READS SQL DATA
BEGIN
    DECLARE v_total INT;
    SELECT COALESCE(SUM(c.creditos), 0) INTO v_total
      FROM grupo_estudiante ge
      JOIN grupo g ON g.id_grupo = ge.id_grupo
      JOIN curso c ON c.id_curso = g.id_curso
     WHERE ge.id_estudiante = p_id_estudiante;
    RETURN v_total;
END$$

-- ---------------------------------------------------------------------
-- PROCEDIMIENTOS (transacción + manejo de excepciones)
-- Si algo falla se hace ROLLBACK y se relanza el error original (RESIGNAL).
-- OJO: START TRANSACTION dentro de un procedimiento confirma cualquier
-- transacción que el cliente tuviera abierta; el back debe llamarlos fuera
-- de un método @Transactional.
-- ---------------------------------------------------------------------
DROP PROCEDURE IF EXISTS sp_inscribir_estudiante$$
CREATE PROCEDURE sp_inscribir_estudiante(
    IN  p_id_grupo        INT,
    IN  p_id_estudiante   VARCHAR(20),
    OUT p_cupos_restantes INT)
BEGIN
    DECLARE v_estado_grupo VARCHAR(20);
    DECLARE v_cupo_max     INT;
    DECLARE v_id_curso     INT;
    DECLARE v_nombre_curso VARCHAR(200);
    DECLARE v_existe_est   INT DEFAULT 0;
    DECLARE v_estado_est   VARCHAR(30);
    DECLARE v_id_plan      INT;
    DECLARE v_n            INT DEFAULT 0;
    DECLARE v_msg          VARCHAR(128);

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Bloquea la fila del grupo: dos inscripciones simultáneas no pueden pasarse del cupo
    SELECT g.estado_grupo, g.cupo_maximo, g.id_curso, c.nombre_curso
      INTO v_estado_grupo, v_cupo_max, v_id_curso, v_nombre_curso
      FROM grupo g JOIN curso c ON c.id_curso = g.id_curso
     WHERE g.id_grupo = p_id_grupo
       FOR UPDATE;
    IF v_id_curso IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 30001, MESSAGE_TEXT = 'No existe el grupo indicado';
    END IF;

    SELECT COUNT(*) INTO v_existe_est FROM estudiante WHERE id = p_id_estudiante;
    IF v_existe_est = 0 THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 30002, MESSAGE_TEXT = 'No existe el estudiante indicado';
    END IF;
    SELECT estado_estudiante, id_plan INTO v_estado_est, v_id_plan
      FROM estudiante WHERE id = p_id_estudiante;

    IF v_estado_est = 'INACTIVO' THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 30004,
            MESSAGE_TEXT = 'El estudiante está inactivo y no puede inscribirse';
    END IF;
    IF v_estado_grupo = 'CERRADO' THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 30004, MESSAGE_TEXT = 'El grupo está cerrado';
    END IF;
    IF v_id_plan IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 30004,
            MESSAGE_TEXT = 'El estudiante no tiene un plan de estudios asignado';
    END IF;

    SELECT COUNT(*) INTO v_n FROM plan_estudios_curso
     WHERE id_plan = v_id_plan AND id_curso = v_id_curso;
    IF v_n = 0 THEN
        -- SIGNAL solo admite literales o variables en MESSAGE_TEXT, no expresiones
        SET v_msg = CONCAT('El curso ', LEFT(v_nombre_curso, 60),
                           ' no pertenece al plan de estudios del estudiante');
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 30004, MESSAGE_TEXT = v_msg;
    END IF;

    SELECT COUNT(*) INTO v_n FROM grupo_estudiante
     WHERE id_grupo = p_id_grupo AND id_estudiante = p_id_estudiante;
    IF v_n > 0 THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 30003, MESSAGE_TEXT = 'El estudiante ya está inscrito en el grupo';
    END IF;

    SELECT COUNT(*) INTO v_n FROM grupo_estudiante WHERE id_grupo = p_id_grupo;
    IF v_n >= v_cupo_max THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 30004, MESSAGE_TEXT = 'El grupo no tiene cupos disponibles';
    END IF;

    INSERT INTO grupo_estudiante (id_grupo, id_estudiante) VALUES (p_id_grupo, p_id_estudiante);

    COMMIT;
    SET p_cupos_restantes = v_cupo_max - v_n - 1;
END$$

DROP PROCEDURE IF EXISTS sp_retirar_estudiante$$
CREATE PROCEDURE sp_retirar_estudiante(
    IN  p_id_grupo        INT,
    IN  p_id_estudiante   VARCHAR(20),
    OUT p_cupos_restantes INT)
BEGIN
    DECLARE v_cupo_max INT;
    DECLARE v_n        INT DEFAULT 0;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    SELECT cupo_maximo INTO v_cupo_max FROM grupo WHERE id_grupo = p_id_grupo FOR UPDATE;
    IF v_cupo_max IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 30001, MESSAGE_TEXT = 'No existe el grupo indicado';
    END IF;

    DELETE FROM grupo_estudiante WHERE id_grupo = p_id_grupo AND id_estudiante = p_id_estudiante;
    IF ROW_COUNT() = 0 THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 30005, MESSAGE_TEXT = 'El estudiante no está inscrito en el grupo';
    END IF;

    COMMIT;
    SELECT COUNT(*) INTO v_n FROM grupo_estudiante WHERE id_grupo = p_id_grupo;
    SET p_cupos_restantes = v_cupo_max - v_n;
END$$

-- ---------------------------------------------------------------------
-- TRIGGERS (solo donde la regla consulta otra tabla o deja rastro)
-- ---------------------------------------------------------------------
-- Cupo y grupo cerrado, aunque alguien inserte directo sin usar el procedimiento
DROP TRIGGER IF EXISTS trg_grupo_estudiante_bi$$
CREATE TRIGGER trg_grupo_estudiante_bi BEFORE INSERT ON grupo_estudiante
FOR EACH ROW
BEGIN
    DECLARE v_max    INT;
    DECLARE v_estado VARCHAR(20);
    DECLARE v_n      INT;
    SELECT cupo_maximo, estado_grupo INTO v_max, v_estado FROM grupo WHERE id_grupo = NEW.id_grupo;
    IF v_estado = 'CERRADO' THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 30004, MESSAGE_TEXT = 'El grupo está cerrado';
    END IF;
    SELECT COUNT(*) INTO v_n FROM grupo_estudiante WHERE id_grupo = NEW.id_grupo;
    IF v_n >= v_max THEN
        SIGNAL SQLSTATE '45000' SET MYSQL_ERRNO = 30004, MESSAGE_TEXT = 'El grupo no tiene cupos disponibles';
    END IF;
END$$

-- Auditoría de inscripciones y retiros
DROP TRIGGER IF EXISTS trg_grupo_estudiante_ai$$
CREATE TRIGGER trg_grupo_estudiante_ai AFTER INSERT ON grupo_estudiante
FOR EACH ROW
BEGIN
    INSERT INTO auditoria (operacion, id_grupo, id_estudiante, usuario_bd)
    VALUES ('INSCRIBIR', NEW.id_grupo, NEW.id_estudiante, USER());
END$$

DROP TRIGGER IF EXISTS trg_grupo_estudiante_ad$$
CREATE TRIGGER trg_grupo_estudiante_ad AFTER DELETE ON grupo_estudiante
FOR EACH ROW
BEGIN
    INSERT INTO auditoria (operacion, id_grupo, id_estudiante, usuario_bd)
    VALUES ('RETIRAR', OLD.id_grupo, OLD.id_estudiante, USER());
END$$

DELIMITER ;

-- ---------------------------------------------------------------------
-- SEGURIDAD: usuarios con privilegios mínimos (cambiar las claves)
--   horarios_app    : el back. Datos + ejecutar procedimientos; sin DDL.
--   horarios_lector : solo consulta.
-- ---------------------------------------------------------------------
CREATE USER IF NOT EXISTS 'horarios_app'@'localhost'    IDENTIFIED BY 'Cambiar_Clave_App_2026';
CREATE USER IF NOT EXISTS 'horarios_lector'@'localhost' IDENTIFIED BY 'Cambiar_Clave_Lector_2026';
GRANT SELECT, INSERT, UPDATE, DELETE, EXECUTE ON sistema_horarios.* TO 'horarios_app'@'localhost';
GRANT SELECT ON sistema_horarios.* TO 'horarios_lector'@'localhost';
FLUSH PRIVILEGES;
