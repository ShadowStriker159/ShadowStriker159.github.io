-- =====================================================================
-- 03_datos_prueba.sql
-- Datos de demostración. Ejecutar DESPUÉS del esquema y de 02_logica_negocio.sql.
-- Las inscripciones se hacen llamando al procedimiento almacenado, así el
-- seed también demuestra su uso (y deja auditoría).
--
-- Claves de demostración (texto plano, como las compara hoy el back):
--   todos los usuarios -> Clave123
--   administradores 9001 (COORDINADOR), 9002 (SECRETARIA)
--   docentes 1001-1006   estudiantes 2001-2008 (2008 está INACTIVO)
-- =====================================================================
SET NAMES utf8mb4;
USE sistema_horarios;

-- Estructura académica ------------------------------------------------
INSERT INTO facultad (id_facultad, nombre_facultad) VALUES
    (1, 'Facultad de Ingeniería'),
    (2, 'Facultad de Medicina');

INSERT INTO area (id_area, id_facultad, nombre_area, descripcion) VALUES
    (1, 1, 'Sistemas e Informática', 'Programación, bases de datos y redes'),
    (2, 1, 'Ciencias Básicas',       'Matemáticas y física'),
    (3, 2, 'Ciencias Morfológicas',  'Anatomía y fisiología');

INSERT INTO carrera (id_carrera, id_facultad, nombre_carrera) VALUES
    (1, 1, 'Ingeniería de Sistemas'),
    (2, 1, 'Ingeniería Industrial'),
    (3, 2, 'Medicina');

INSERT INTO plan_estudios (id_plan, id_carrera, nombre_plan) VALUES
    (1, 1, 'Plan Sistemas 2024'),
    (2, 2, 'Plan Industrial 2024'),
    (3, 3, 'Plan Medicina 2024');

INSERT INTO curso (id_curso, nombre_curso, intensidad_horaria, semestre, creditos, aula_requerida) VALUES
    (1,  'Cálculo Diferencial',          4, 1, 3, 'GRUPAL'),
    (2,  'Programación I',               4, 1, 3, 'SISTEMAS'),
    (3,  'Álgebra Lineal',               3, 1, 3, 'GRUPAL'),
    (4,  'Cálculo Integral',             4, 2, 3, 'GRUPAL'),
    (5,  'Programación II',              4, 2, 3, 'SISTEMAS'),
    (6,  'Bases de Datos I',             4, 3, 3, 'SISTEMAS'),
    (7,  'Bases de Datos II',            4, 4, 4, 'SISTEMAS'),
    (8,  'Física Mecánica',              4, 2, 3, 'GRUPAL'),
    (9,  'Probabilidad y Estadística',   3, 3, 3, 'GRUPAL'),
    (10, 'Anatomía',                     6, 1, 4, 'MEDICINA'),
    (11, 'Fisiología',                   6, 2, 4, 'MEDICINA');

INSERT INTO curso_prerrequisito (id_curso, id_prerrequisito) VALUES
    (4, 1), (5, 2), (6, 5), (7, 6), (11, 10);

INSERT INTO plan_estudios_curso (id_plan, id_curso) VALUES
    (1, 1), (1, 2), (1, 3), (1, 4), (1, 5), (1, 6), (1, 7),
    (2, 1), (2, 3), (2, 4), (2, 8), (2, 9),
    (3, 10), (3, 11);

-- Infraestructura -----------------------------------------------------
INSERT INTO bloque (id_bloque, nombre_bloque, etiqueta_bloque, ubicacion) VALUES
    (1, 'Bloque A',     'A', 'Campus principal - sector norte'),
    (2, 'Bloque B',     'B', 'Campus principal - sector sur'),
    (3, 'Bloque Salud', 'S', 'Sede clínica');

INSERT INTO aula (id_bloque, numero_aula, capacidad, tipo_aula, estado_aula) VALUES
    (1, 'A-101', 40, 'GRUPAL',   'DISPONIBLE'),
    (1, 'A-102', 40, 'GRUPAL',   'DISPONIBLE'),
    (1, 'A-201', 30, 'SISTEMAS', 'DISPONIBLE'),
    (2, 'B-101', 35, 'GRUPAL',   'DISPONIBLE'),
    (2, 'B-201', 30, 'SISTEMAS', 'DISPONIBLE'),
    (2, 'B-202', 30, 'SISTEMAS', 'DISPONIBLE'),
    (3, 'S-101', 25, 'MEDICINA', 'DISPONIBLE'),
    (3, 'S-102', 25, 'MEDICINA', 'DISPONIBLE');

-- 5 días x 4 franjas = 20 franjas
INSERT INTO franja_horaria (dia_semana, hora_inicio, hora_fin, estado_franja, categoria)
SELECT d.dia, h.ini, h.fin, 'DISPONIBLE', h.cat
  FROM (SELECT 'LUNES' AS dia UNION ALL SELECT 'MARTES' UNION ALL SELECT 'MIERCOLES'
        UNION ALL SELECT 'JUEVES' UNION ALL SELECT 'VIERNES') d
 CROSS JOIN (SELECT '07:00:00' AS ini, '09:00:00' AS fin, 'DIA'   AS cat
             UNION ALL SELECT '09:00:00', '11:00:00', 'DIA'
             UNION ALL SELECT '14:00:00', '16:00:00', 'TARDE'
             UNION ALL SELECT '18:00:00', '20:00:00', 'NOCHE') h;

-- Personas ------------------------------------------------------------
INSERT INTO persona (id, nombre, apellido, password, correo) VALUES
    ('9001', 'Sara',     'Gil',       'Clave123', 'sara.gil@ejemplo.edu.co'),
    ('9002', 'Mateo',    'Cruz',      'Clave123', 'mateo.cruz@ejemplo.edu.co'),
    ('1001', 'Ana',      'Ruiz',      'Clave123', 'ana.ruiz@ejemplo.edu.co'),
    ('1002', 'Carlos',   'Pardo',     'Clave123', 'carlos.pardo@ejemplo.edu.co'),
    ('1003', 'Lucía',    'Herrera',   'Clave123', 'lucia.herrera@ejemplo.edu.co'),
    ('1004', 'Jorge',    'Navarro',   'Clave123', 'jorge.navarro@ejemplo.edu.co'),
    ('1005', 'Marta',    'Quintero',  'Clave123', 'marta.quintero@ejemplo.edu.co'),
    ('1006', 'Felipe',   'Salcedo',   'Clave123', 'felipe.salcedo@ejemplo.edu.co'),
    ('2001', 'Luis',     'Mora',      'Clave123', 'luis.mora@ejemplo.edu.co'),
    ('2002', 'Paula',    'Rojas',     'Clave123', 'paula.rojas@ejemplo.edu.co'),
    ('2003', 'Andrés',   'Vargas',    'Clave123', 'andres.vargas@ejemplo.edu.co'),
    ('2004', 'Camila',   'Torres',    'Clave123', 'camila.torres@ejemplo.edu.co'),
    ('2005', 'Daniel',   'Ortiz',     'Clave123', 'daniel.ortiz@ejemplo.edu.co'),
    ('2006', 'Valentina','Suárez',    'Clave123', 'valentina.suarez@ejemplo.edu.co'),
    ('2007', 'Sebastián','León',      'Clave123', 'sebastian.leon@ejemplo.edu.co'),
    ('2008', 'Laura',    'Mejía',     'Clave123', 'laura.mejia@ejemplo.edu.co');

INSERT INTO administrador (id, tipo_administrador) VALUES
    ('9001', 'COORDINADOR'),
    ('9002', 'SECRETARIA');

INSERT INTO docente (id, escalafon, estado_docente, tipo_vinculacion) VALUES
    ('1001', 'PROFESOR_TITULAR',   'ACTIVO', 'TC'),
    ('1002', 'PROFESOR_ASOCIADO',  'ACTIVO', 'TC'),
    ('1003', 'PROFESOR_ASISTENTE', 'ACTIVO', 'MTO'),
    ('1004', 'INSTRUCTOR_ASOCIADO','ACTIVO', 'MTO'),
    ('1005', 'PROFESOR_TITULAR',   'ACTIVO', 'TC'),
    ('1006', 'PROFESOR_ASISTENTE', 'ACTIVO', 'HC');

-- Disponibilidad: lunes a jueves, 07-09, 09-11 y 14-16 (los de 1006 también incluyen la noche)
INSERT INTO docente_franja (id_docente, id_franja)
SELECT d.id, f.id_franja
  FROM docente d
  JOIN franja_horaria f
    ON f.dia_semana IN ('LUNES', 'MARTES', 'MIERCOLES', 'JUEVES')
   AND f.hora_inicio IN ('07:00:00', '09:00:00', '14:00:00');
INSERT INTO docente_franja (id_docente, id_franja)
SELECT '1006', id_franja FROM franja_horaria WHERE hora_inicio = '18:00:00';

INSERT INTO estudiante (id, id_plan, estado_estudiante, semestre_cursa, creditos_aprobados) VALUES
    ('2001', 1, 'ACTIVO',   1,  0),
    ('2002', 1, 'ACTIVO',   1,  0),
    ('2003', 1, 'ACTIVO',   2, 12),
    ('2004', 1, 'ACTIVO',   3, 24),
    ('2005', 2, 'ACTIVO',   2, 10),
    ('2006', 2, 'ACTIVO',   1,  0),
    ('2007', 3, 'ACTIVO',   1,  0),
    ('2008', 3, 'INACTIVO', 4, 40);

-- Grupos (ids 1..12 en este orden) --------------------------------------
INSERT INTO grupo (id_curso, id_docente, estado_grupo, cupo_maximo, cupo_minimo) VALUES
    (1,  '1001', 'ABIERTO', 40, 5),   -- 1  Cálculo Diferencial
    (2,  '1002', 'ABIERTO', 30, 5),   -- 2  Programación I
    (3,  '1001', 'ABIERTO', 40, 5),   -- 3  Álgebra Lineal
    (4,  '1001', 'ABIERTO', 40, 5),   -- 4  Cálculo Integral
    (5,  '1002', 'ABIERTO', 30, 5),   -- 5  Programación II
    (6,  '1003', 'ABIERTO', 30, 5),   -- 6  Bases de Datos I
    (8,  '1004', 'ABIERTO', 35, 5),   -- 7  Física Mecánica
    (9,  '1004', 'ABIERTO', 35, 5),   -- 8  Probabilidad y Estadística
    (10, '1005', 'ABIERTO', 25, 5),   -- 9  Anatomía
    (11, '1005', 'ABIERTO', 25, 5),   -- 10 Fisiología
    (7,  '1003', 'CERRADO', 30, 5),   -- 11 Bases de Datos II (cerrado)
    (1,  '1006', 'ABIERTO',  3, 1);   -- 12 Cálculo Diferencial, 2.º grupo, cupo 3

-- Inscripciones (vía procedimiento) ------------------------------------
CALL sp_inscribir_estudiante(1,  '2001', @c);
CALL sp_inscribir_estudiante(2,  '2001', @c);
CALL sp_inscribir_estudiante(3,  '2001', @c);
CALL sp_inscribir_estudiante(1,  '2002', @c);
CALL sp_inscribir_estudiante(2,  '2002', @c);
CALL sp_inscribir_estudiante(12, '2003', @c);
CALL sp_inscribir_estudiante(12, '2004', @c);
CALL sp_inscribir_estudiante(12, '2005', @c);          -- el grupo 12 queda lleno (3/3)
CALL sp_inscribir_estudiante(7,  '2005', @c);
CALL sp_inscribir_estudiante(8,  '2005', @c);
CALL sp_inscribir_estudiante(7,  '2006', @c);
CALL sp_inscribir_estudiante(9,  '2007', @c);
