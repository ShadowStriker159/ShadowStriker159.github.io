-- =====================================================================
-- 06_reportes.sql
-- Vistas y consultas de reporte de SistemaHorario (MySQL 8.4).
-- Ejecutar DESPUÉS de 02, 03 y 05. Las consultas parametrizadas usan variables
-- de sesión (@id_estudiante, @dia, @hora) que se fijan justo antes.
-- =====================================================================
USE sistema_horarios;

-- ---------------------------------------------------------------------
-- VISTAS
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW v_cupos_grupo AS
SELECT g.id_grupo,
       c.nombre_curso,
       CONCAT(p.nombre, ' ', p.apellido) AS docente,
       g.estado_grupo,
       g.cupo_minimo,
       g.cupo_maximo,
       COUNT(ge.id_estudiante)                 AS inscritos,
       g.cupo_maximo - COUNT(ge.id_estudiante) AS cupos_disponibles,
       ROUND(100 * COUNT(ge.id_estudiante) / g.cupo_maximo, 1) AS pct_ocupacion
  FROM grupo g
  JOIN curso   c ON c.id_curso = g.id_curso
  JOIN persona p ON p.id       = g.id_docente
  LEFT JOIN grupo_estudiante ge ON ge.id_grupo = g.id_grupo
 GROUP BY g.id_grupo, c.nombre_curso, p.nombre, p.apellido,
          g.estado_grupo, g.cupo_minimo, g.cupo_maximo;

CREATE OR REPLACE VIEW v_horario_secciones AS
SELECT s.id_seccion,
       s.id_grupo,
       c.nombre_curso,
       g.id_docente,
       CONCAT(p.nombre, ' ', p.apellido) AS docente,
       b.etiqueta_bloque,
       s.numero_aula,
       f.dia_semana,
       f.hora_inicio,
       f.hora_fin,
       s.estado_seccion
  FROM seccion s
  JOIN grupo          g ON g.id_grupo   = s.id_grupo
  JOIN curso          c ON c.id_curso   = g.id_curso
  JOIN persona        p ON p.id         = g.id_docente
  JOIN bloque         b ON b.id_bloque  = s.id_bloque
  JOIN franja_horaria f ON f.id_franja  = s.id_franja;

-- ---------------------------------------------------------------------
-- R1. Cupos por grupo (vista + función del esquema)
-- ---------------------------------------------------------------------
SELECT v.*, fn_cupos_disponibles(v.id_grupo) AS cupos_segun_funcion
  FROM v_cupos_grupo v
 ORDER BY v.pct_ocupacion DESC, v.id_grupo;

-- ---------------------------------------------------------------------
-- R2. Grupos abiertos por debajo del cupo mínimo (HAVING)
-- ---------------------------------------------------------------------
SELECT g.id_grupo, c.nombre_curso, g.cupo_minimo,
       COUNT(ge.id_estudiante) AS inscritos
  FROM grupo g
  JOIN curso c ON c.id_curso = g.id_curso
  LEFT JOIN grupo_estudiante ge ON ge.id_grupo = g.id_grupo
 WHERE g.estado_grupo = 'ABIERTO'
 GROUP BY g.id_grupo, c.nombre_curso, g.cupo_minimo
HAVING COUNT(ge.id_estudiante) < g.cupo_minimo
 ORDER BY g.id_grupo;

-- ---------------------------------------------------------------------
-- R3. Carga académica por docente
-- ---------------------------------------------------------------------
SELECT d.id AS id_docente,
       CONCAT(p.nombre, ' ', p.apellido) AS docente,
       d.tipo_vinculacion,
       COUNT(DISTINCT g.id_grupo)   AS grupos,
       COUNT(s.id_seccion)          AS secciones_semana,
       ROUND(COALESCE(SUM((TIME_TO_SEC(f.hora_fin)
                         - TIME_TO_SEC(f.hora_inicio)) / 3600), 0), 1) AS horas_semana
  FROM docente d
  JOIN persona p ON p.id = d.id
  LEFT JOIN grupo g          ON g.id_docente = d.id
  LEFT JOIN seccion s        ON s.id_grupo   = g.id_grupo
  LEFT JOIN franja_horaria f ON f.id_franja  = s.id_franja
 GROUP BY d.id, p.nombre, p.apellido, d.tipo_vinculacion
 ORDER BY horas_semana DESC, d.id;

-- ---------------------------------------------------------------------
-- R4. Horario semanal de un estudiante
-- ---------------------------------------------------------------------
SET @id_estudiante = '2001';
SELECT f.dia_semana, f.hora_inicio, f.hora_fin,
       c.nombre_curso, b.etiqueta_bloque, s.numero_aula,
       CONCAT(pd.nombre, ' ', pd.apellido) AS docente
  FROM grupo_estudiante ge
  JOIN grupo          g  ON g.id_grupo  = ge.id_grupo
  JOIN curso          c  ON c.id_curso  = g.id_curso
  JOIN persona        pd ON pd.id       = g.id_docente
  JOIN seccion        s  ON s.id_grupo  = g.id_grupo
  JOIN bloque         b  ON b.id_bloque = s.id_bloque
  JOIN franja_horaria f  ON f.id_franja = s.id_franja
 WHERE ge.id_estudiante = @id_estudiante
 ORDER BY FIELD(f.dia_semana, 'LUNES', 'MARTES', 'MIERCOLES', 'JUEVES', 'VIERNES'),
          f.hora_inicio;

-- ---------------------------------------------------------------------
-- R5. Ocupación de aulas (el JOIN usa la llave compuesta de aula)
-- ---------------------------------------------------------------------
SELECT b.etiqueta_bloque, a.numero_aula, a.tipo_aula, a.capacidad,
       COUNT(s.id_seccion) AS franjas_ocupadas,
       ROUND(100 * COUNT(s.id_seccion) /
             (SELECT COUNT(*) FROM franja_horaria), 1) AS pct_uso
  FROM aula a
  JOIN bloque b ON b.id_bloque = a.id_bloque
  LEFT JOIN seccion s ON s.id_bloque = a.id_bloque AND s.numero_aula = a.numero_aula
 GROUP BY b.etiqueta_bloque, a.id_bloque, a.numero_aula, a.tipo_aula, a.capacidad
 ORDER BY pct_uso DESC, a.numero_aula;

-- ---------------------------------------------------------------------
-- R6. Aulas disponibles y libres en una franja (subconsulta NOT EXISTS)
-- ---------------------------------------------------------------------
SET @dia = 'LUNES';
SET @hora = '07:00:00';
SELECT a.numero_aula, a.tipo_aula, a.capacidad
  FROM aula a
 WHERE a.estado_aula = 'DISPONIBLE'
   AND NOT EXISTS (
         SELECT 1
           FROM seccion s
           JOIN franja_horaria f ON f.id_franja = s.id_franja
          WHERE s.id_bloque = a.id_bloque
            AND s.numero_aula = a.numero_aula
            AND f.dia_semana = @dia
            AND f.hora_inicio = @hora)
 ORDER BY a.tipo_aula, a.numero_aula;

-- ---------------------------------------------------------------------
-- R7. Estudiantes activos por facultad y carrera
-- ---------------------------------------------------------------------
SELECT fa.nombre_facultad, ca.nombre_carrera,
       COUNT(e.id)                  AS estudiantes_activos,
       ROUND(AVG(e.semestre_cursa), 1) AS semestre_promedio
  FROM estudiante e
  JOIN plan_estudios pl ON pl.id_plan    = e.id_plan
  JOIN carrera       ca ON ca.id_carrera = pl.id_carrera
  JOIN facultad      fa ON fa.id_facultad = ca.id_facultad
 WHERE e.estado_estudiante = 'ACTIVO'
 GROUP BY fa.nombre_facultad, ca.nombre_carrera
 ORDER BY estudiantes_activos DESC, ca.nombre_carrera;

-- ---------------------------------------------------------------------
-- R8. Créditos inscritos frente a aprobados (función del esquema)
-- ---------------------------------------------------------------------
SELECT e.id, CONCAT(p.nombre, ' ', p.apellido) AS estudiante,
       e.semestre_cursa, e.creditos_aprobados,
       fn_creditos_inscritos(e.id) AS creditos_inscritos
  FROM estudiante e
  JOIN persona p ON p.id = e.id
 WHERE e.estado_estudiante = 'ACTIVO'
 ORDER BY creditos_inscritos DESC, e.id;

-- ---------------------------------------------------------------------
-- R9. Cursos con su prerrequisito (autounión sobre curso)
-- ---------------------------------------------------------------------
SELECT c.nombre_curso AS curso, c.semestre,
       pr.nombre_curso AS prerrequisito
  FROM curso c
  JOIN curso_prerrequisito cp ON cp.id_curso = c.id_curso
  JOIN curso pr               ON pr.id_curso = cp.id_prerrequisito
 ORDER BY c.semestre, c.nombre_curso;

-- ---------------------------------------------------------------------
-- R10. Cursos sin ningún grupo abierto (NOT EXISTS)
-- ---------------------------------------------------------------------
SELECT c.id_curso, c.nombre_curso, c.semestre
  FROM curso c
 WHERE NOT EXISTS (SELECT 1 FROM grupo g
                    WHERE g.id_curso = c.id_curso
                      AND g.estado_grupo = 'ABIERTO')
 ORDER BY c.id_curso;

-- ---------------------------------------------------------------------
-- R11. Cursos más demandados (CTE + función de ventana)
-- ---------------------------------------------------------------------
WITH demanda AS (
    SELECT c.id_curso, c.nombre_curso, COUNT(ge.id_estudiante) AS inscritos
      FROM curso c
      JOIN grupo g ON g.id_curso = c.id_curso
      LEFT JOIN grupo_estudiante ge ON ge.id_grupo = g.id_grupo
     GROUP BY c.id_curso, c.nombre_curso
)
SELECT RANK() OVER (ORDER BY inscritos DESC) AS puesto, nombre_curso, inscritos
  FROM demanda
 WHERE inscritos > 0
 ORDER BY puesto, nombre_curso;

-- ---------------------------------------------------------------------
-- R12. Choques de aula (la tabla seccion no tiene UNIQUE para esto)
-- ---------------------------------------------------------------------
SELECT s1.id_seccion AS seccion_a, s2.id_seccion AS seccion_b,
       s1.numero_aula, f.dia_semana, f.hora_inicio
  FROM seccion s1
  JOIN seccion s2 ON s1.id_seccion < s2.id_seccion
                 AND s1.id_bloque = s2.id_bloque
                 AND s1.numero_aula = s2.numero_aula
                 AND s1.id_franja = s2.id_franja
  JOIN franja_horaria f ON f.id_franja = s1.id_franja;

-- ---------------------------------------------------------------------
-- R13. Choques de docente
-- ---------------------------------------------------------------------
SELECT s1.id_seccion AS seccion_a, s2.id_seccion AS seccion_b,
       g1.id_docente, f.dia_semana, f.hora_inicio
  FROM seccion s1
  JOIN grupo g1 ON g1.id_grupo = s1.id_grupo
  JOIN seccion s2 ON s1.id_seccion < s2.id_seccion
                 AND s1.id_franja = s2.id_franja
  JOIN grupo g2 ON g2.id_grupo = s2.id_grupo
                AND g2.id_docente = g1.id_docente
  JOIN franja_horaria f ON f.id_franja = s1.id_franja;

-- ---------------------------------------------------------------------
-- R14. Secciones fuera de la disponibilidad declarada del docente
-- ---------------------------------------------------------------------
SELECT s.id_seccion, g.id_docente, f.dia_semana, f.hora_inicio
  FROM seccion s
  JOIN grupo g          ON g.id_grupo  = s.id_grupo
  JOIN franja_horaria f ON f.id_franja = s.id_franja
 WHERE NOT EXISTS (SELECT 1 FROM docente_franja df
                    WHERE df.id_docente = g.id_docente
                      AND df.id_franja  = s.id_franja);

-- ---------------------------------------------------------------------
-- R15. Grupos cuyo cupo máximo supera la capacidad del aula asignada
-- ---------------------------------------------------------------------
SELECT DISTINCT g.id_grupo, g.cupo_maximo, s.numero_aula, a.capacidad
  FROM seccion s
  JOIN grupo g ON g.id_grupo = s.id_grupo
  JOIN aula  a ON a.id_bloque = s.id_bloque AND a.numero_aula = s.numero_aula
 WHERE g.cupo_maximo > a.capacidad;

-- ---------------------------------------------------------------------
-- R16. Choques de horario de un estudiante entre sus grupos
-- ---------------------------------------------------------------------
SELECT ge1.id_estudiante, s1.id_grupo AS grupo_a, s2.id_grupo AS grupo_b,
       f.dia_semana, f.hora_inicio
  FROM grupo_estudiante ge1
  JOIN grupo_estudiante ge2 ON ge2.id_estudiante = ge1.id_estudiante
                           AND ge2.id_grupo > ge1.id_grupo
  JOIN seccion s1 ON s1.id_grupo = ge1.id_grupo
  JOIN seccion s2 ON s2.id_grupo = ge2.id_grupo AND s2.id_franja = s1.id_franja
  JOIN franja_horaria f ON f.id_franja = s1.id_franja;

-- ---------------------------------------------------------------------
-- R17. Auditoría: movimientos por día y operación
-- ---------------------------------------------------------------------
SELECT DATE(fecha) AS dia, operacion, COUNT(*) AS movimientos,
       COUNT(DISTINCT id_estudiante) AS estudiantes
  FROM auditoria
 GROUP BY DATE(fecha), operacion
 ORDER BY dia DESC, operacion;

-- ---------------------------------------------------------------------
-- R18. Docentes sin carga asignada (LEFT JOIN ... IS NULL)
-- ---------------------------------------------------------------------
SELECT d.id, CONCAT(p.nombre, ' ', p.apellido) AS docente
  FROM docente d
  JOIN persona p ON p.id = d.id
  LEFT JOIN grupo g ON g.id_docente = d.id
 WHERE g.id_grupo IS NULL;
