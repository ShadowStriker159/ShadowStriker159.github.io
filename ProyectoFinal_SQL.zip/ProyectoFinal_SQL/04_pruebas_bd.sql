-- =====================================================================
-- 04_pruebas_bd.sql
-- Pruebas automáticas de la lógica de negocio en la base de datos.
-- Ejecutar DESPUÉS del esquema, 02 y 03, sobre la base recién cargada.
-- Cada prueba imprime OK o FALLA y al final hay un resumen.
-- =====================================================================
SET NAMES utf8mb4;
USE sistema_horarios;

DROP TABLE IF EXISTS _resultados;
CREATE TABLE _resultados (
    n INT AUTO_INCREMENT PRIMARY KEY, seccion VARCHAR(40), prueba VARCHAR(150),
    esperado VARCHAR(100), obtenido VARCHAR(100), ok TINYINT, mensaje VARCHAR(300)
);
SET @seccion = '';

DELIMITER $$
DROP PROCEDURE IF EXISTS _t_error$$
-- Ejecuta una sentencia y compara el error obtenido con el esperado.
-- p_errno: 0 = debe funcionar; -1 = debe fallar con cualquier error; otro = ese MYSQL_ERRNO.
CREATE PROCEDURE _t_error(IN p_prueba VARCHAR(150), IN p_sql TEXT, IN p_errno INT)
BEGIN
    DECLARE v_errno INT DEFAULT 0;
    DECLARE v_msg   TEXT DEFAULT '';
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1 v_errno = MYSQL_ERRNO, v_msg = MESSAGE_TEXT;
    END;
    SET @_sql = p_sql;
    PREPARE st FROM @_sql;
    EXECUTE st;
    DEALLOCATE PREPARE st;
    INSERT INTO _resultados (seccion, prueba, esperado, obtenido, ok, mensaje)
    VALUES (@seccion, p_prueba,
            IF(p_errno = -1, 'cualquier error', IF(p_errno = 0, 'sin error', CONCAT('error ', p_errno))),
            IF(v_errno = 0, 'sin error', CONCAT('error ', v_errno)),
            IF(p_errno = -1, v_errno <> 0, v_errno = p_errno), LEFT(v_msg, 300));
END$$

DROP PROCEDURE IF EXISTS _t_valor$$
-- Evalúa una expresión y compara su valor (como texto) con el esperado.
CREATE PROCEDURE _t_valor(IN p_prueba VARCHAR(150), IN p_expr TEXT, IN p_esperado VARCHAR(100))
BEGIN
    DECLARE v_obtenido VARCHAR(100);
    SET @_sql = CONCAT('SELECT (', p_expr, ') INTO @_r');
    PREPARE st FROM @_sql;
    EXECUTE st;
    DEALLOCATE PREPARE st;
    SET v_obtenido = COALESCE(CAST(@_r AS CHAR), 'NULL');
    INSERT INTO _resultados (seccion, prueba, esperado, obtenido, ok, mensaje)
    VALUES (@seccion, p_prueba, p_esperado, v_obtenido, v_obtenido = p_esperado, NULL);
END$$
DELIMITER ;


SET @seccion = 'FUNCIONES';
CALL _t_valor('fn_cupos_disponibles: grupo con 2 inscritos de 40', 'fn_cupos_disponibles(1)', '38');
CALL _t_valor('fn_cupos_disponibles: grupo lleno devuelve 0', 'fn_cupos_disponibles(12)', '0');
CALL _t_valor('fn_cupos_disponibles: grupo inexistente devuelve NULL', 'fn_cupos_disponibles(99999)', 'NULL');
CALL _t_valor('fn_creditos_inscritos: estudiante con 3 cursos de 3 créditos', 'fn_creditos_inscritos(''2001'')', '9');
CALL _t_valor('fn_creditos_inscritos: estudiante inexistente devuelve 0', 'fn_creditos_inscritos(''NOEXISTE'')', '0');

SET @seccion = 'sp_inscribir_estudiante';
CALL _t_error('inscribir: caso válido', 'CALL sp_inscribir_estudiante(1, ''2006'', @c)', 0);
CALL _t_valor('inscribir: devuelve los cupos restantes', '@c', '37');
CALL _t_error('inscribir: ya inscrito', 'CALL sp_inscribir_estudiante(1, ''2001'', @c)', 30003);
CALL _t_error('inscribir: grupo sin cupos', 'CALL sp_inscribir_estudiante(12, ''2007'', @c)', 30004);
CALL _t_error('inscribir: grupo cerrado', 'CALL sp_inscribir_estudiante(11, ''2001'', @c)', 30004);
CALL _t_error('inscribir: estudiante inactivo', 'CALL sp_inscribir_estudiante(9, ''2008'', @c)', 30004);
CALL _t_error('inscribir: curso fuera del plan del estudiante', 'CALL sp_inscribir_estudiante(9, ''2001'', @c)', 30004);
CALL _t_error('inscribir: grupo inexistente', 'CALL sp_inscribir_estudiante(99999, ''2001'', @c)', 30001);
CALL _t_error('inscribir: estudiante inexistente', 'CALL sp_inscribir_estudiante(1, ''NOEXISTE'', @c)', 30002);
CALL _t_error('atomicidad: contar inscripciones antes de un intento fallido', 'SET @antes = (SELECT COUNT(*) FROM grupo_estudiante)', 0);
CALL _t_error('atomicidad: intento fallido', 'CALL sp_inscribir_estudiante(12, ''2007'', @c)', 30004);
CALL _t_valor('atomicidad: el intento fallido no dejó nada (ROLLBACK)', '(SELECT COUNT(*) FROM grupo_estudiante) = @antes', '1');

SET @seccion = 'sp_retirar_estudiante';
CALL _t_error('retirar: caso válido', 'CALL sp_retirar_estudiante(1, ''2006'', @c)', 0);
CALL _t_valor('retirar: devuelve los cupos restantes', '@c', '38');
CALL _t_error('retirar: estudiante que no está inscrito', 'CALL sp_retirar_estudiante(1, ''2006'', @c)', 30005);
CALL _t_error('retirar: grupo inexistente', 'CALL sp_retirar_estudiante(99999, ''2001'', @c)', 30001);

SET @seccion = 'TRIGGERS';
CALL _t_error('trigger cupo: insert directo en grupo lleno', 'INSERT INTO grupo_estudiante VALUES (12, ''2007'')', 30004);
CALL _t_error('trigger cerrado: insert directo en grupo cerrado', 'INSERT INTO grupo_estudiante VALUES (11, ''2001'')', 30004);
CALL _t_error('auditoría: contar filas antes', 'SET @aud = (SELECT COUNT(*) FROM auditoria)', 0);
CALL _t_error('auditoría: inscribir', 'CALL sp_inscribir_estudiante(1, ''2006'', @c)', 0);
CALL _t_error('auditoría: retirar', 'CALL sp_retirar_estudiante(1, ''2006'', @c)', 0);
CALL _t_valor('auditoría: quedaron 2 registros', '(SELECT COUNT(*) FROM auditoria) - @aud', '2');
CALL _t_valor('auditoría: el último registro es el retiro de 2006', '(SELECT CONCAT(operacion, '':'', id_estudiante) FROM auditoria ORDER BY id_auditoria DESC LIMIT 1)', 'RETIRAR:2006');

SET @seccion = 'INTEGRIDAD Y RESTRICCIONES';
CALL _t_error('check grupo: cupo máximo menor al mínimo', 'UPDATE grupo SET cupo_maximo = 2 WHERE id_grupo = 4', -1);
CALL _t_error('check grupo: estado inválido', 'INSERT INTO grupo (id_curso, id_docente, estado_grupo, cupo_maximo, cupo_minimo) VALUES (1, ''1001'', ''XX'', 10, 1)', -1);
CALL _t_error('check aula: capacidad 0', 'INSERT INTO aula VALUES (1, ''T-1'', 0, ''GRUPAL'', ''DISPONIBLE'')', -1);
CALL _t_error('FK: no se puede borrar un docente con datos asociados', 'DELETE FROM docente WHERE id = ''1001''', -1);
CALL _t_error('UNIQUE: correo repetido', 'INSERT INTO persona VALUES (''T901'', ''A'', ''B'', ''x'', ''luis.mora@ejemplo.edu.co'')', -1);

-- Resultado ------------------------------------------------------------
SELECT n, seccion, prueba, esperado, obtenido, IF(ok, 'OK', 'FALLA') AS resultado, mensaje
  FROM _resultados ORDER BY n;
SELECT seccion, COUNT(*) AS pruebas, SUM(ok) AS ok, COUNT(*) - SUM(ok) AS fallas
  FROM _resultados GROUP BY seccion ORDER BY MIN(n);
SELECT COUNT(*) AS total, SUM(ok) AS ok, COUNT(*) - SUM(ok) AS fallas FROM _resultados;

DROP PROCEDURE IF EXISTS _t_error;
DROP PROCEDURE IF EXISTS _t_valor;
-- Para borrar la tabla de resultados: DROP TABLE _resultados;
