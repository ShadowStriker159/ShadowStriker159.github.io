-- =====================================================================
-- 05_secciones_demo.sql
-- Secciones (horario) de demostración para poder probar los reportes.
-- Ejecutar DESPUÉS de 03_datos_prueba.sql. En producción las secciones las
-- genera el algoritmo genético (POST /api/horarios/generar); este script solo
-- deja un horario coherente: respeta la disponibilidad del docente, el tipo y
-- la capacidad del aula, y no tiene choques de aula ni de docente.
-- =====================================================================
USE sistema_horarios;

INSERT INTO seccion (estado_seccion, id_grupo, id_bloque, numero_aula, id_franja)
SELECT 'ASIGNADA', t.g, t.b, t.a, f.id_franja
  FROM (SELECT 1 AS g, 1 AS b, 'A-101' AS a, 'LUNES' AS d, '07:00:00' AS h
        UNION ALL SELECT 1, 1, 'A-101', 'MIERCOLES', '07:00:00'
        UNION ALL SELECT 2, 1, 'A-201', 'LUNES',     '09:00:00'
        UNION ALL SELECT 2, 1, 'A-201', 'JUEVES',    '09:00:00'
        UNION ALL SELECT 3, 1, 'A-102', 'MARTES',    '07:00:00'
        UNION ALL SELECT 4, 1, 'A-101', 'MARTES',    '09:00:00'
        UNION ALL SELECT 4, 1, 'A-101', 'JUEVES',    '09:00:00'
        UNION ALL SELECT 5, 2, 'B-201', 'MARTES',    '07:00:00'
        UNION ALL SELECT 5, 2, 'B-201', 'JUEVES',    '07:00:00'
        UNION ALL SELECT 6, 2, 'B-202', 'MIERCOLES', '09:00:00'
        UNION ALL SELECT 6, 2, 'B-202', 'JUEVES',    '14:00:00'
        UNION ALL SELECT 7, 2, 'B-101', 'LUNES',     '14:00:00'
        UNION ALL SELECT 7, 2, 'B-101', 'MIERCOLES', '14:00:00'
        UNION ALL SELECT 8, 2, 'B-101', 'MARTES',    '14:00:00'
        UNION ALL SELECT 9, 3, 'S-101', 'LUNES',     '07:00:00'
        UNION ALL SELECT 9, 3, 'S-101', 'MIERCOLES', '07:00:00'
        UNION ALL SELECT 10, 3, 'S-102', 'MARTES',   '09:00:00'
        UNION ALL SELECT 10, 3, 'S-102', 'JUEVES',   '09:00:00'
        UNION ALL SELECT 12, 1, 'A-102', 'LUNES',    '18:00:00'
        UNION ALL SELECT 12, 1, 'A-102', 'MIERCOLES','18:00:00') t
  JOIN franja_horaria f
    ON f.dia_semana = t.d AND f.hora_inicio = t.h;
