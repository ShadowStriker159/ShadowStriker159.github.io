
/*  TALLER MQL - CONSULTAS, AGREGACION E INDICES EN MONGODB
    Bases de Datos 2 - Universidad El Bosque
    Integrantes: Erik Bautista / Felipe Lopez
    Base de datos: sample_mflix (MongoDB Atlas - Sample Dataset)**/

// PARTE A 

// ---------------------------------------------------------------------------
// PUNTO 1. Drama, 2000-2010 (inclusive), imdb.rating >= 8.
// Logica: genres es un arreglo; {genres: "Drama"} coincide si lo CONTIENE.
// El rango de year usa $gte/$lte. El filtro $gte: 8 sobre imdb.rating descarta
// los valores "" (un texto no se compara con numeros). El conteo usa el mismo
// filtro, sin limit.
// ---------------------------------------------------------------------------
use ('sample_mflix');
db.movies.find(
  { genres: "Drama", 
    year: { $gte: 2000, $lte: 2010 }, 
    "imdb.rating": { $gte: 8 } },
  { _id: 0, title: 1, year: 1, "imdb.rating": 1 }
).sort({ "imdb.rating": -1 }).limit(10);

use ('sample_mflix');
db.movies.countDocuments(
  { genres: "Drama", 
    year: { $gte: 2000, $lte: 2010 }, 
    "imdb.rating": { $gte: 8 } }
);


// ---------------------------------------------------------------------------
// PUNTO 2. Peliculas con Tom Hanks cuyo director NO sea Steven Spielberg.
// Logica: cast y directors son arreglos. {cast: "Tom Hanks"} busca el valor
// dentro del arreglo. {directors: {$ne: "Steven Spielberg"}} se cumple cuando
// ningun elemento del arreglo es Spielberg (incluye documentos sin directors).
// ---------------------------------------------------------------------------
use ('sample_mflix');
db.movies.find(
  { cast: "Tom Hanks", 
    directors: { $ne: "Steven Spielberg" } },
  { _id: 0, title: 1, year: 1, directors: 1 }
).sort({ year: 1 });

use ('sample_mflix');
db.movies.countDocuments(
  { cast: "Tom Hanks", directors: { $ne: "Steven Spielberg" } }
);


// ---------------------------------------------------------------------------
// PUNTO 3. Exactamente 3 generos e incluyan Comedy y Romance.
// Logica: $all exige que el arreglo contenga TODOS los valores (en cualquier
// orden); $size exige longitud exacta. Se combinan sobre el mismo campo.
//   $in   -> al menos UNO de los valores (OR)
//   $all  -> TODOS los valores (AND)
//   $size -> longitud exacta (no admite rangos como $gt)
// ---------------------------------------------------------------------------
use ('sample_mflix');
db.movies.find(
  { genres: { $all: ["Comedy", "Romance"], $size: 3 } },
  { _id: 0, title: 1, year: 1, genres: 1 }
).limit(5);

use ('sample_mflix');
db.movies.countDocuments(
  { genres: { $all: ["Comedy", "Romance"], $size: 3 } }
);


// ---------------------------------------------------------------------------
// PUNTO 4. Sin el campo rated, o con valor "UNRATED" o "NOT RATED".
// Logica: $or con dos condiciones. {$exists: false} detecta documentos sin el
// campo; $in compara contra los dos valores de texto.
// ---------------------------------------------------------------------------
use ('sample_mflix');
db.movies.find(
  { $or: [ { rated: { $exists: false } }, { rated: { $in: ["UNRATED", "NOT RATED"] } } ] },
  { _id: 0, title: 1, year: 1, rated: 1 }
).limit(5);

use ('sample_mflix');
db.movies.countDocuments(
  { $or: [ { rated: { $exists: false } }, { rated: { $in: ["UNRATED", "NOT RATED"] } } ] }
);

// ---------------------------------------------------------------------------
// PUNTO 5. Titulos que empiecen por "The" y terminen en "Man", sin distinguir
// mayusculas de minusculas.
// Logica: expresion regular con anclas ^ (inicio) y $ (fin); .* admite
// cualquier texto en medio; $options: "i" ignora mayusculas/minusculas.
// Variante con "Man" como palabra completa (excluye "Woman", "Superman"):
//   { title: { $regex: "^The\\b.*\\bMan$", $options: "i" } }
// ---------------------------------------------------------------------------
use ('sample_mflix');
db.movies.find(
  { title: { $regex: "^The.*Man$", $options: "i" } },
  { _id: 0, title: 1, year: 1 }
).sort({ title: 1 });

use ('sample_mflix');
db.movies.countDocuments(
  { title: { $regex: "^The.*Man$", $options: "i" } }
);


// PARTE B - AGREGACION (puntos 6 a 10)
use('sample_mflix');
/*
6.ara cada género calcule: número de películas, rating IMDb promedio (redondeado a 2 decimales) y rating
máximo. Muestre solo los géneros con más de 500 películas, ordenados por promedio descendente. Nota:
imdb.rating contiene valores vacíos (""); filtre únicamente valores numéricos.
*/

use('sample_mflix');

db.getCollection('movies').aggregate([
  //aca elimino los ratings con valores vacios
  { $match: { "imdb.rating": { $type: "number" } } },

  // aca desenrollo el array de generos para poder agruparlo correctamente
  { $unwind: "$genres" },

  //aca agrupo por genero y calculo promedio, cantidad, y maximo de cada particion genero
  { $group: {
      _id: "$genres",
      cantidad: { $sum: 1 },
      rating_promedio: { $avg: "$imdb.rating" },
      rating_maximo: { $max: "$imdb.rating" }
  } },

  //aca filtro para traer los mayores (exluyente ) de 500
  { $match: { cantidad: { $gt: 500 } } },

  //aca hago una proyeccion para mostrar solo lo que me piden
  { $project: {
      _id: 0,
      genero: "$_id",
      cantidad: 1,
      rating_promedio: { $round: ["$rating_promedio", 2] },
      rating_maximo: 1
  } },

  //aca ordeno de mayor a menor con el -1
  { $sort: { rating_promedio: -1 } }
]);


/*
7. Obtenga el Top 5 de directores con más películas con imdb.rating mayor o igual a 7.5 (mínimo 5 películas).
Muestre el director, la cantidad y una lista de máximo 3 títulos.
*/
use('sample_mflix');
db.getCollection('movies').aggregate([
  // aca filtro solo ratings con numeros mayores o iguales a 7.5
  { $match: { "imdb.rating": { $type: "number", $gte: 7.5 } } },

  // aca desenrollo el arreglo para poder agrupar correctamnete mas adelante
  { $unwind: "$directors" },

  { $group: {
      _id: "$directors",
      cantidad: { $sum: 1 },
      titulos: { $push: "$title" }
  } },

  // aca filtroo aquellos que sean menor o igual 5 en cantidad de peliculas
  { $match: { cantidad: { $gte: 5 } } },

  //aca organizo los directores par aobtener los mejores 5
  { $sort: { cantidad: -1, _id: 1 } },

  // aca traigo solo los primeros 5
  { $limit: 5 },

  // aca uso proyeccion para solo traer los campos relevantes
  { $project: {
      _id: 0,
      director: "$_id",
      cantidad: 1,
      titulos: { $slice: ["$titulos", 3] }
  } }
]);


/*
8. Calcule el número de películas por década (1950s, 1960s, ...) a partir de 1950.
*/
use('sample_mflix');

db.getCollection('movies').aggregate([
  //aca filtro para traer años con valor numerico
  { $match: { year: { $type: "number", $gte: 1950 } } },

  //aca agrupo por rango en años
  { $bucket: {
      groupBy: "$year",
      boundaries: [1950, 1960, 1970, 1980, 1990, 2000, 2010, 2020, 2030],
      default: "otro",
      output: { cantidad: { $sum: 1 } }
  } }
]);

/*
9. Obtenga el Top 10 de películas más comentadas: título, año y número de comentarios (utilice $lookup entre
comments y movies).
*/
use('sample_mflix');

db.getCollection('comments').aggregate([
  //aca cuento los comentarios por pelicula
  { $group: {
      _id: "$movie_id",
      num_comentarios: { $sum: 1 }
  } },

  //aca ordeno las peliculas de mayor a menor
  { $sort: { num_comentarios: -1 } },
  
  //aca tomo las 10 mejores peliculas
  { $limit: 10 },

  //aca hago el look up (join)
  { $lookup: {
      from: "movies",
      localField: "_id",
      foreignField: "_id",
      as: "pelicula"
  } },

  //el look up nos da un arreglo asi que tenemos que desenrollarlo en objetos ṕara usarlo correctamente
  { $unwind: "$pelicula" },

  //aca uso una proyeccion para mostrar solo los datos relevantes
  { $project: {
      _id: 0,
      titulo: "$pelicula.title",
      año: "$pelicula.year",
      num_comentarios: 1
  } }
]);


/*
10. Liste los usuarios (por email) con más de 250 comentarios, indicando la fecha de su primer y último comentario.
*/
use('sample_mflix');

db.getCollection('comments').aggregate([

  // aca agrupo por gmail los comentarios y calculo el ultimo, el primero y la cantidad en total de comentarios
  { $group: {
      _id: "$email",
      num_comentarios: { $sum: 1 },
      primer_comentario: { $min: "$date" },
      ultimo_comentario: { $max: "$date" }
  } },

  //aca filtro para solo traer los comentarios mayores que 250 excluyente
  { $match: { num_comentarios: { $gt: 250 } } },

  //aca uso una proyeccion para solo traer los campos relevantes
  { $project: {
      _id: 0,
      email: "$_id",
      num_comentarios: 1,
      primer_comentario: 1,
      ultimo_comentario: 1
  } }
]);
// PARTE C - ESCRITURA E INDICES


// ---------------------------------------------------------------------------
// PUNTO 11. Crear peliculas_pareja con $out: peliculas de 2015 con titulo,
// generos, rating y el campo calculado categoria.
// Logica: $match deja solo 2015 con rating NUMERICO; es necesario porque en
// una comparacion de agregacion un texto ("") se ordena despues de cualquier
// numero y "" >= 7.5 daria true (categoria "Alta" por error). $project
// renombra imdb.rating a rating y calcula categoria con $switch, que usa la
// primera rama que se cumple. $out reemplaza la coleccion si ya existe.
// ---------------------------------------------------------------------------
use ('sample_mflix');
db.movies.aggregate([
  { $match: { year: 2015, "imdb.rating": { $type: "number" } } },
  { $project: {
      title: 1,
      genres: 1,
      rating: "$imdb.rating",
      categoria: {
        $switch: {
          branches: [
            { case: { $gte: ["$imdb.rating", 7.5] }, then: "Alta" },
            { case: { $gte: ["$imdb.rating", 6] },   then: "Media" }
          ],
          default: "Baja"
        }
      }
  } },
  { $out: "peliculas_pareja" }
]);

// Verificacion primeros documentos, conteo y distribucion para que no quede vacia:
use ('sample_mflix');
db.peliculas_pareja.find().limit(5)
db.peliculas_pareja.countDocuments()
db.peliculas_pareja.aggregate([
  { $group: { _id: "$categoria", total: { $sum: 1 } } },
  { $sort: { _id: 1 } }
]);


// ---------------------------------------------------------------------------
// PUNTO 12. updateMany: agregar revisado: true e incrementar 0.1 el rating de
// las peliculas de categoria "Media". Reportar matchedCount y modifiedCount.
// Logica: el filtro selecciona categoria "Media"; $set establece revisado y
// $inc suma 0.1 al rating.
// ---------------------------------------------------------------------------
use ('sample_mflix');
db.peliculas_pareja.updateMany(
  { categoria: "Media" },
  { $set: { revisado: true }, 
  $inc: { rating: 0.1 } }
);
// ---------------------------------------------------------------------------
// PUNTO 13. deleteMany: eliminar las peliculas de categoria "Baja".
// Logica: deleteMany borra todos los documentos que cumplen el filtro y
// devuelve deletedCount.
// ---------------------------------------------------------------------------
use ('sample_mflix');
db.peliculas_pareja.deleteMany({ categoria: "Baja" });

// ---------------------------------------------------------------------------
// PUNTO 14. explain("executionStats") de la consulta del punto 1, ANTES y
// DESPUES de crear un indice compuesto segun la regla ESR.
// Consulta: igualdad en genres, rango en year, rango y orden en imdb.rating.
// Indice ESR: { genres: 1 (Equality), "imdb.rating": -1 (Sort), year: 1 (Range) }
// ---------------------------------------------------------------------------

// 14.a) ANTES de crear el indice
use ('sample_mflix');
db.movies.find(
  { genres: "Drama", 
    year: { $gte: 2000, $lte: 2010 }, 
    "imdb.rating": { $gte: 8 } },
  { _id: 0, title: 1, year: 1, "imdb.rating": 1 }
).sort({ "imdb.rating": -1 }).limit(10).explain("executionStats");

// 14.b) Crear el indice compuesto ESR
    use ('sample_mflix');
    db.movies.createIndex(
    { genres: 1,
        "imdb.rating": -1, 
        year: 1 },
    { name: "idx_genres_rating_year" }
    );

// 14.c) DESPUES de crear el indice
use('sample_mflix');
db.movies.find(
  { genres: "Drama", 
    year: { $gte: 2000, $lte: 2010 }, 
    "imdb.rating": { $gte: 8 } },
  { _id: 0, title: 1, year: 1, "imdb.rating": 1 }
).sort({ "imdb.rating": -1 }).limit(10).explain("executionStats");

// 14.e) Eliminar el indice creado
use ('sample_mflix');
db.movies.dropIndex("idx_genres_rating_year");
db.movies.getIndexes();