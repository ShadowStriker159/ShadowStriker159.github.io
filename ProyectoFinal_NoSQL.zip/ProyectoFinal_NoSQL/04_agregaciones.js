// =====================================================================
// 04_agregaciones.js  (mongosh)
// Agregaciones sobre horarios_nosql. Son las mismas que usa el back en
// GET /api/horarios/nosql/resumen.
// =====================================================================
use("horarios_nosql");

// A1. Eventos por tipo y resultado
printjson(db.bitacora_eventos.aggregate([
  { $group: { _id: { tipo: "$tipo", resultado: "$resultado" }, total: { $sum: 1 } } },
  { $sort: { total: -1 } }
]).toArray());

// A2. Demanda real: inscripciones exitosas por grupo
printjson(db.bitacora_eventos.aggregate([
  { $match: { tipo: "INSCRIPCION", resultado: "OK" } },
  { $group: { _id: "$grupo", inscripciones: { $sum: 1 } } },
  { $sort: { inscripciones: -1 } }
]).toArray());

// A3. Motivos de rechazo con ejemplos de mensaje
printjson(db.bitacora_eventos.aggregate([
  { $match: { resultado: "RECHAZADO" } },
  { $group: { _id: "$error", total: { $sum: 1 }, mensajes: { $addToSet: "$mensaje" } } },
  { $sort: { total: -1 } }
]).toArray());

// A4. Secciones por día en la última generación exitosa ($unwind del arreglo embebido)
printjson(db.historial_generaciones.aggregate([
  { $match: { resultado: "OK" } },
  { $sort: { fecha: -1 } },
  { $limit: 1 },
  { $unwind: "$secciones" },
  { $group: { _id: "$secciones.dia", secciones: { $sum: 1 } } },
  { $sort: { secciones: -1 } }
]).toArray());

// A5. Carga docente (secciones por docente) en la última generación
printjson(db.historial_generaciones.aggregate([
  { $match: { resultado: "OK" } },
  { $sort: { fecha: -1 } },
  { $limit: 1 },
  { $unwind: "$secciones" },
  { $group: { _id: "$secciones.docente", secciones: { $sum: 1 }, materias: { $addToSet: "$secciones.materia" } } },
  { $sort: { secciones: -1 } }
]).toArray());

// A6. Tasa de éxito y duración promedio de las generaciones
printjson(db.historial_generaciones.aggregate([
  { $group: {
      _id: null,
      intentos: { $sum: 1 },
      exitosas: { $sum: { $cond: [{ $eq: ["$resultado", "OK"] }, 1, 0] } },
      duracionPromedioMs: { $avg: "$duracionMs" } } },
  { $project: { _id: 0, intentos: 1, exitosas: 1, duracionPromedioMs: { $round: ["$duracionPromedioMs", 0] },
      tasaExito: { $round: [{ $multiply: [{ $divide: ["$exitosas", "$intentos"] }, 100] }, 1] } } }
]).toArray());

// A7. Eventos por día (serie diaria) con $dateToString
printjson(db.bitacora_eventos.aggregate([
  { $group: { _id: { $dateToString: { format: "%Y-%m-%d", date: "$fecha" } }, eventos: { $sum: 1 } } },
  { $sort: { _id: 1 } }
]).toArray());
