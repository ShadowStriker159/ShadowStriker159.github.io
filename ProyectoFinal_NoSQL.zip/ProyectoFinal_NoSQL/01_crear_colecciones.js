// =====================================================================
// 01_crear_colecciones.js  (mongosh)
// Crea la base horarios_nosql, sus colecciones con validación y los índices.
// Ejecutar:  mongosh --file 01_crear_colecciones.js
// =====================================================================
use("horarios_nosql");

// Si se vuelve a ejecutar, se parte de cero.
["historial_generaciones", "bitacora_eventos", "notificaciones"].forEach(function (c) {
  db.getCollection(c).drop();
});

// ---- historial_generaciones: una foto por cada intento de generar el horario -----------
db.createCollection("historial_generaciones", {
  validator: { $jsonSchema: {
    bsonType: "object",
    required: ["fecha", "idFacultad", "resultado", "duracionMs", "totalSecciones", "secciones"],
    properties: {
      fecha:          { bsonType: "date" },
      idFacultad:     { bsonType: ["int", "long"] },
      nombreFacultad: { bsonType: ["string", "null"] },
      resultado:      { enum: ["OK", "FALLIDA"] },
      mensaje:        { bsonType: "string" },
      duracionMs:     { bsonType: ["int", "long"], minimum: 0 },
      totalSecciones: { bsonType: ["int", "long"], minimum: 0 },
      nota:           { bsonType: "string" },
      secciones: {
        bsonType: "array",
        items: {
          bsonType: "object",
          required: ["grupo", "materia", "dia", "horaInicial", "horaFinal"],
          properties: {
            numero:      { bsonType: ["int", "long"] },
            grupo:       { bsonType: "string" },
            materia:     { bsonType: "string" },
            programa:    { bsonType: ["string", "null"] },
            docente:     { bsonType: ["string", "null"] },
            bloque:      { bsonType: ["string", "null"] },
            aula:        { bsonType: ["string", "null"] },
            dia:         { enum: ["LUNES", "MARTES", "MIERCOLES", "JUEVES", "VIERNES", "SABADO"] },
            horaInicial: { bsonType: "string" },
            horaFinal:   { bsonType: "string" },
            estado:      { bsonType: ["string", "null"] }
          }
        }
      }
    }
  } }
});
db.historial_generaciones.createIndex({ fecha: -1 }, { name: "ix_historial_fecha" });
db.historial_generaciones.createIndex({ idFacultad: 1, fecha: -1 }, { name: "ix_historial_facultad_fecha" });

// ---- bitacora_eventos: inscripciones y retiros, con su resultado ------------------------
db.createCollection("bitacora_eventos", {
  validator: { $jsonSchema: {
    bsonType: "object",
    required: ["tipo", "fecha", "resultado", "grupo", "estudiante"],
    properties: {
      tipo:          { enum: ["INSCRIPCION", "RETIRO"] },
      fecha:         { bsonType: "date" },
      resultado:     { enum: ["OK", "RECHAZADO"] },
      grupo:         { bsonType: ["int", "long"] },
      estudiante:    { bsonType: "string" },
      error:         { bsonType: "string" },
      mensaje:       { bsonType: "string" },
      cuposRestantes:{ bsonType: ["int", "long"] }
    }
  } }
});
db.bitacora_eventos.createIndex({ fecha: -1 }, { name: "ix_bitacora_fecha" });
db.bitacora_eventos.createIndex({ estudiante: 1, fecha: -1 }, { name: "ix_bitacora_estudiante" });
db.bitacora_eventos.createIndex({ grupo: 1, tipo: 1 }, { name: "ix_bitacora_grupo_tipo" });
// La bitácora se depura sola: los eventos de más de 180 días se eliminan.
db.bitacora_eventos.createIndex({ fecha: 1 }, { name: "ttl_bitacora_180d", expireAfterSeconds: 15552000 });

// ---- notificaciones: correos de verificación enviados (sin el contenido) ----------------
db.createCollection("notificaciones", {
  validator: { $jsonSchema: {
    bsonType: "object",
    required: ["fecha", "rol", "usuario", "canal", "asunto", "estado"],
    properties: {
      fecha:   { bsonType: "date" },
      rol:     { enum: ["estudiante", "docente", "administrador"] },
      usuario: { bsonType: "string" },
      canal:   { enum: ["CORREO"] },
      asunto:  { bsonType: "string" },
      estado:  { enum: ["ENVIADA", "FALLIDA"] }
    }
  } }
});
db.notificaciones.createIndex({ usuario: 1, fecha: -1 }, { name: "ix_notif_usuario_fecha" });
db.notificaciones.createIndex({ estado: 1 }, { name: "ix_notif_estado" });

print("Colecciones: " + db.getCollectionNames().join(", "));
