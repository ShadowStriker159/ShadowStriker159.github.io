// =====================================================================
// 03_crud_y_consultas.js  (mongosh)
// CRUD y consultas complejas sobre horarios_nosql.
// =====================================================================
use("horarios_nosql");

// ------------------------------ CREATE ------------------------------
db.bitacora_eventos.insertOne({
  tipo: "INSCRIPCION", fecha: new Date(), resultado: "OK",
  grupo: Int32(4), estudiante: "2004", cuposRestantes: Int32(39)
});

// ------------------------------ READ ------------------------------
// C1. Últimos 5 eventos de un estudiante
printjson(db.bitacora_eventos.find({ estudiante: "2001" }).sort({ fecha: -1 }).limit(5).toArray());

// C2. Rechazos por falta de cupo o grupo cerrado (búsqueda por texto del mensaje)
printjson(db.bitacora_eventos.find({
  resultado: "RECHAZADO",
  mensaje: { $regex: /cupos|cerrado/i }
}, { _id: 0, estudiante: 1, grupo: 1, mensaje: 1 }).toArray());

// C3. Generaciones exitosas con más de 4 secciones, sin traer el arreglo completo
printjson(db.historial_generaciones.find(
  { resultado: "OK", totalSecciones: { $gt: 4 } },
  { secciones: 0 }).toArray());

// C4. Generaciones que tienen alguna sección de Programación I los jueves (consulta sobre el arreglo embebido)
printjson(db.historial_generaciones.find(
  { secciones: { $elemMatch: { materia: "Programación I", dia: "JUEVES" } } },
  { fecha: 1, totalSecciones: 1 }).toArray());

// C5. Correos fallidos del último día
printjson(db.notificaciones.find({
  estado: "FALLIDA",
  fecha: { $gte: new Date(Date.now() - 24 * 3600 * 1000) }
}).toArray());

// ------------------------------ UPDATE ------------------------------
// U1. Anotar una revisión sobre la generación más reciente exitosa
const ultima = db.historial_generaciones.find({ resultado: "OK" }).sort({ fecha: -1 }).limit(1).toArray()[0];
db.historial_generaciones.updateOne(
  { _id: ultima._id },
  { $set: { nota: "Revisada por coordinación", notaFecha: new Date() } });

// U2. Normalizar el nombre de un docente en todas las fotos del historial (actualiza elementos del arreglo)
db.historial_generaciones.updateMany(
  { "secciones.docente": "Lucía Herrera" },
  { $set: { "secciones.$[s].docente": "Lucía Herrera Gómez" } },
  { arrayFilters: [{ "s.docente": "Lucía Herrera" }] });

// ------------------------------ DELETE ------------------------------
// D1. Borrar el evento de prueba que se creó arriba
db.bitacora_eventos.deleteOne({ estudiante: "2004", grupo: Int32(4), tipo: "INSCRIPCION" });

// D2. Depurar notificaciones fallidas de más de 30 días
db.notificaciones.deleteMany({
  estado: "FALLIDA",
  fecha: { $lt: new Date(Date.now() - 30 * 24 * 3600 * 1000) }
});

print("CRUD y consultas ejecutados.");
