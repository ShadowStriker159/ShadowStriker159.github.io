// =====================================================================
// 02_datos_ejemplo.js  (mongosh)
// Datos de demostración coherentes con el seed de MySQL (03_datos_prueba.sql).
// Ejecutar después de 01:  mongosh --file 02_datos_ejemplo.js
// =====================================================================
use("horarios_nosql");

// Los números de los validadores se escriben como Int32 para cumplir el esquema.
const I = function (n) { return Int32(n); };
const dia = function (n, h) { return ISODate("2026-11-" + n + "T" + h + ":00:00Z"); };

db.historial_generaciones.insertMany([
  {
    fecha: dia("10", "15"), idFacultad: I(1), nombreFacultad: "Facultad de Ingeniería",
    resultado: "OK", duracionMs: I(1840), totalSecciones: I(6),
    secciones: [
      { numero: I(1), grupo: "1", materia: "Cálculo Diferencial", programa: "Ingeniería de Sistemas", docente: "Ana Ruiz",
        bloque: "A", aula: "Aula A-101", dia: "LUNES", horaInicial: "07:00", horaFinal: "09:00", estado: "ASIGNADA" },
      { numero: I(2), grupo: "1", materia: "Cálculo Diferencial", programa: "Ingeniería de Sistemas", docente: "Ana Ruiz",
        bloque: "A", aula: "Aula A-101", dia: "MIERCOLES", horaInicial: "07:00", horaFinal: "09:00", estado: "ASIGNADA" },
      { numero: I(3), grupo: "2", materia: "Programación I", programa: "Ingeniería de Sistemas", docente: "Carlos Pardo",
        bloque: "A", aula: "Aula A-201", dia: "LUNES", horaInicial: "09:00", horaFinal: "11:00", estado: "ASIGNADA" },
      { numero: I(4), grupo: "2", materia: "Programación I", programa: "Ingeniería de Sistemas", docente: "Carlos Pardo",
        bloque: "A", aula: "Aula A-201", dia: "JUEVES", horaInicial: "09:00", horaFinal: "11:00", estado: "ASIGNADA" },
      { numero: I(5), grupo: "3", materia: "Álgebra Lineal", programa: "Ingeniería de Sistemas", docente: "Ana Ruiz",
        bloque: "A", aula: "Aula A-102", dia: "MARTES", horaInicial: "07:00", horaFinal: "09:00", estado: "ASIGNADA" },
      { numero: I(6), grupo: "6", materia: "Bases de Datos I", programa: "Ingeniería de Sistemas", docente: "Lucía Herrera",
        bloque: "B", aula: "Aula B-202", dia: "MIERCOLES", horaInicial: "09:00", horaFinal: "11:00", estado: "ASIGNADA" }
    ]
  },
  {
    fecha: dia("12", "16"), idFacultad: I(1), nombreFacultad: "Facultad de Ingeniería",
    resultado: "OK", duracionMs: I(2105), totalSecciones: I(3),
    secciones: [
      { numero: I(1), grupo: "1", materia: "Cálculo Diferencial", programa: "Ingeniería de Sistemas", docente: "Ana Ruiz",
        bloque: "A", aula: "Aula A-101", dia: "LUNES", horaInicial: "07:00", horaFinal: "09:00", estado: "ASIGNADA" },
      { numero: I(2), grupo: "2", materia: "Programación I", programa: "Ingeniería de Sistemas", docente: "Carlos Pardo",
        bloque: "A", aula: "Aula A-201", dia: "LUNES", horaInicial: "09:00", horaFinal: "11:00", estado: "ASIGNADA" },
      { numero: I(3), grupo: "7", materia: "Física Mecánica", programa: "Ingeniería Industrial", docente: "Jorge Navarro",
        bloque: "B", aula: "Aula B-101", dia: "MARTES", horaInicial: "14:00", horaFinal: "16:00", estado: "ASIGNADA" }
    ]
  },
  {
    fecha: dia("13", "10"), idFacultad: I(9), nombreFacultad: null,
    resultado: "FALLIDA", mensaje: "Facultad no encontrada.", duracionMs: I(12), totalSecciones: I(0), secciones: []
  }
]);

db.bitacora_eventos.insertMany([
  { tipo: "INSCRIPCION", fecha: dia("13", "08"), resultado: "OK", grupo: I(1), estudiante: "2001", cuposRestantes: I(39) },
  { tipo: "INSCRIPCION", fecha: dia("13", "08"), resultado: "OK", grupo: I(2), estudiante: "2001", cuposRestantes: I(29) },
  { tipo: "INSCRIPCION", fecha: dia("13", "09"), resultado: "OK", grupo: I(1), estudiante: "2002", cuposRestantes: I(38) },
  { tipo: "INSCRIPCION", fecha: dia("13", "09"), resultado: "OK", grupo: I(12), estudiante: "2003", cuposRestantes: I(2) },
  { tipo: "INSCRIPCION", fecha: dia("13", "09"), resultado: "OK", grupo: I(12), estudiante: "2004", cuposRestantes: I(1) },
  { tipo: "INSCRIPCION", fecha: dia("13", "10"), resultado: "OK", grupo: I(12), estudiante: "2005", cuposRestantes: I(0) },
  { tipo: "INSCRIPCION", fecha: dia("13", "11"), resultado: "RECHAZADO", grupo: I(12), estudiante: "2006",
    error: "IllegalArgumentException", mensaje: "El grupo no tiene cupos disponibles" },
  { tipo: "INSCRIPCION", fecha: dia("13", "11"), resultado: "RECHAZADO", grupo: I(11), estudiante: "2002",
    error: "IllegalArgumentException", mensaje: "El grupo está cerrado" },
  { tipo: "INSCRIPCION", fecha: dia("13", "12"), resultado: "RECHAZADO", grupo: I(1), estudiante: "2001",
    error: "GrupoRepetidoException", mensaje: "El estudiante ya está inscrito en el grupo" },
  { tipo: "INSCRIPCION", fecha: dia("13", "12"), resultado: "RECHAZADO", grupo: I(1), estudiante: "2008",
    error: "IllegalArgumentException", mensaje: "El estudiante está inactivo y no puede inscribirse" },
  { tipo: "RETIRO", fecha: dia("13", "14"), resultado: "OK", grupo: I(2), estudiante: "2002", cuposRestantes: I(28) },
  { tipo: "RETIRO", fecha: dia("13", "14"), resultado: "RECHAZADO", grupo: I(3), estudiante: "2003",
    error: "EstudianteNoEncontradoException", mensaje: "El estudiante no está inscrito en el grupo" }
]);

db.notificaciones.insertMany([
  { fecha: dia("13", "07"), rol: "estudiante", usuario: "2001", canal: "CORREO", asunto: "Código de verificación", estado: "ENVIADA" },
  { fecha: dia("13", "09"), rol: "docente", usuario: "1001", canal: "CORREO", asunto: "Código de verificación", estado: "ENVIADA" },
  { fecha: dia("13", "13"), rol: "administrador", usuario: "9001", canal: "CORREO", asunto: "Código de verificación", estado: "FALLIDA" }
]);

print("historial_generaciones: " + db.historial_generaciones.countDocuments());
print("bitacora_eventos: " + db.bitacora_eventos.countDocuments());
print("notificaciones: " + db.notificaciones.countDocuments());
